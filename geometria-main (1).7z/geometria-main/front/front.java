package front;
import back.negocio.Fachada;

public class front {
    public static void main(String[] args) {
        Fachada fachada = new Fachada();

        fachada.criaQuadrado(10.6, "Azul");
        fachada.criaRetangulo(50.5, 20.4, "Amarelo");
        fachada.criaTriangulo(6.5, 10, 7, 9, "Roxo");
        fachada.criaCircunferencia(10, "Branco");

        String mensagem = fachada.mostraAreaObjetos();
        System.out.println(mensagem);

        mensagem = fachada.mostraPerimetroObjetos();
        System.out.println(mensagem);

        mensagem = fachada.mostraCorObjetos();
        System.out.println(mensagem);
    }
}