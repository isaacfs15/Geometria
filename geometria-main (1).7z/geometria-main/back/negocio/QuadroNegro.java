package back.negocio;

import back.dado.*;

public class QuadroNegro {
	private Quadrado quadrado;
	private Retangulo retangulo;
	private Circunferencia circunferencia;
	private Triangulo triangulo;

	public void limpaQuadro() {
		quadrado = null;
		retangulo = null;
		circunferencia = null;
		triangulo = null;
	}

	public void criaQuadrado(double l, String cor) {
		quadrado = new Quadrado(l);
		quadrado.setCor(cor);
	}

	public void criaRetangulo(double c, double a, String cor) {
		retangulo = new Retangulo(c, a);
		retangulo.setCor(cor);
	}

	public void criaCircunferencia(double r, String cor) {
		circunferencia = new Circunferencia(r);
		circunferencia.setCor(cor);
	}

	public void criaTriangulo(double b, double a, double l2, double l3, String cor) {
		triangulo = new Triangulo(b, a, l2, l3);
		triangulo.setCor(cor);
	}

	public String mostraAreaObjetos() {
		String mensagem = "";

		if (quadrado != null) {
			mensagem += "Quadrado.  Área: " + quadrado.getArea() + "\n";
		}
		if (retangulo != null) {
			mensagem += "Retângulo. Área: " + retangulo.getArea() + "\n";
		}
		if (triangulo != null) {
			mensagem += "Triângulo. Área: " + triangulo.getArea() + "\n";
		}
		if (circunferencia != null) {
			mensagem += "Circunferência. Área: " + circunferencia.getArea() + "\n";
		}

		return mensagem;
	}

	public String mostraPerimetroObjetos() {
		String mensagem = "";

		if (quadrado != null) {
			mensagem += "Quadrado.  Perímetro: " + quadrado.getPerimetro() + "\n";
		}
		if (retangulo != null) {
			mensagem += "Retângulo. Perímetro: " + retangulo.getPerimetro() + "\n";
		}
		if (triangulo != null) {
			mensagem += "Triângulo. Perímetro: " + triangulo.getPerimetro() + "\n";
		}
		if (circunferencia != null) {
			mensagem += "Circunferência. Perímetro: " + circunferencia.getPerimetro() + "\n";
		}

		return mensagem;
	}

	public String mostraCorObjetos() {
		String mensagem = "";

		if (quadrado != null) {
			mensagem += "Quadrado.  Cor: " + quadrado.getCor() + "\n";
		}
		if (retangulo != null) {
			mensagem += "Retângulo. Cor: " + retangulo.getCor() + "\n";
		}
		if (triangulo != null) {
			mensagem += "Triângulo. Cor: " + triangulo.getCor() + "\n";
		}
		if (circunferencia != null) {
			mensagem += "Circunferência. Cor: " + circunferencia.getCor() + "\n";
		}

		return mensagem;
	}
}