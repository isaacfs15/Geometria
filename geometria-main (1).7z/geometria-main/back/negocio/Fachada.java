package back.negocio;

public class Fachada implements IFachada {
    private QuadroNegro quadroNegro;

    public Fachada() {
        quadroNegro = new QuadroNegro();
    }

    public void limpaQuadro() {
        quadroNegro.limpaQuadro();
    }

    public void criaQuadrado(double l, String c) {
        quadroNegro.criaQuadrado(l, c);
    }

    public void criaRetangulo(double c, double a, String cor) {
        quadroNegro.criaRetangulo(c, a, cor);
    }

    public void criaCircunferencia(double r, String c) {
        quadroNegro.criaCircunferencia(r, c);
    }

    public void criaTriangulo(double b, double a, double l2, double l3, String c) {
        quadroNegro.criaTriangulo(b, a, l2, l3, c);
    }

    public String mostraAreaObjetos() {
        return quadroNegro.mostraAreaObjetos();
    }

    public String mostraPerimetroObjetos() {
        return quadroNegro.mostraPerimetroObjetos();
    }

    public String mostraCorObjetos() {
        return quadroNegro.mostraCorObjetos();
    }
}