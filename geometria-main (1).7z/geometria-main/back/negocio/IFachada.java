package back.negocio;

public interface IFachada {
    void limpaQuadro();
    void criaQuadrado(double l, String c);
    void criaRetangulo(double c, double a, String cor);
    void criaCircunferencia(double r, String c);
    void criaTriangulo(double b, double a, double l2, double l3, String c);
    String mostraAreaObjetos();
    String mostraPerimetroObjetos();
    String mostraCorObjetos();
}