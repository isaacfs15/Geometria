package back.dado;

public class Triangulo extends ObjetoGeometrico {
	private double base;
	private double altura;
	private double lado2;
	private double lado3;

	public Triangulo(double b, double a, double l2, double l3) {
		base = b;
		altura = a;
		lado2 = l2;
		lado3 = l3;
	}

	public double getArea() {
		area = (base * altura)/2;
		return area;
	}

	public double getPerimetro() {
		perimetro = base + lado2 + lado3;
		return perimetro;
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}
}