package back.dado;

public class Circunferencia extends ObjetoGeometrico {
	private double raio;

	public Circunferencia(double r) {
		raio = r;
	}

	public double getArea() {
		area = Math.PI * (raio * raio);
		return area;
	}

	public double getPerimetro() {
		perimetro = 2 * Math.PI * raio;
		return perimetro;
	}

	public double getRaio() {
		return raio;
	}

	public void setRaio(double raio) {
		this.raio = raio;
	}
}