package back.dado;

public interface InterfaceGeometria {
	double getArea();
	double getPerimetro();
	String getCor();
	void setCor(String c);
}